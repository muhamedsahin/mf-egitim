<html><head>
    <title>
    Din kültürü
    </title>
    <style>
    * { margin: 0; padding: 0; font-family: consolas; }
    body { display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #f2f3f7; }
    a { 
        position: relative;
        display: inline-block;
        padding: 10px 30px;
        text-decoration: none;
        text-transform: uppercase;
        font-weight: 500; 
        letter-spacing: 2px; 
        color: #5a84a2;
        font-size: 18px; 
        border-radius: 40px; 
        box-shadow: -2px -2px 8px rgba(255, 255, 255, 1), -2px -2px 12px rgba(255, 255, 255, 0.5), inset 2px 2px 4px rgba(255, 255, 255, 0.1), 2px 2px 8px rgba(0, 0, 0, 0.15); } a:hover { box-shadow: inset -2px -2px 8px rgba(255, 255, 255, 1), inset -2px -2px 12px rgba(255, 255, 255, 0.5), inset 2px 2px 4px rgba(255, 255, 255, 0.1), inset 2px 2px 8px rgba(0, 0, 0, 0.15);
        }
    a:hover span 
    { display: inline-block; transform: scale(0.98); 
        
    }
    li
    {
        list-style-type:none;
    }
    </style>
    </head>
    <body>
        <li>
        <img src="https://github.com/muhamedsahin/resimlerim/blob/main/e184d419953d2ebf08231aad32f5eb70.png?raw=true" alt="beden"/>
        <ul>
    <a href="#"><span>5.sınıf</span></a>
     <a href="#"><span>6.sınıf</span></a>
      <a href="#"><span>7.sınıf</span></a>
       <a href="#"><span>8.sınıf</span></a>
    </ul>
    </li>
    </body></html>